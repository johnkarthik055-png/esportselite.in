import { Clock, Flag } from 'lucide-react'
import { formatDuration } from '../utils/helpers.js'

/**
 * Combined daily session banner. Shows current activity counts and an
 * "End Today's Session" action. Hidden until the user has any activity.
 *
 * Props:
 *   drillCount, matchCount, totalDuration, status, onEndSession
 */
export default function SessionBanner({
  drillCount = 0,
  matchCount = 0,
  totalDuration = 0,
  status = 'not_started',
  onEndSession,
}) {
  const hasActivity = drillCount > 0 || matchCount > 0
  const isCompleted = status === 'completed'

  if (!hasActivity && !isCompleted) return null

  return (
    <div className="session-banner">
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, minWidth: 0 }}>
        <span className="session-banner-dot" />
        <div style={{ minWidth: 0 }}>
          <div
            style={{
              fontFamily: 'Inter, sans-serif',
              fontSize: 13,
              fontWeight: 600,
              color: 'var(--green)',
              letterSpacing: '0.01em',
            }}
          >
            Session Active
          </div>
          <div
            style={{
              fontSize: 12,
              color: 'var(--text-muted)',
              display: 'flex',
              gap: 8,
              flexWrap: 'wrap',
              marginTop: 2,
            }}
          >
            <span>{drillCount} drill{drillCount === 1 ? '' : 's'}</span>
            <span style={{ color: 'var(--text-subtle)' }}>•</span>
            <span>{matchCount} match{matchCount === 1 ? '' : 'es'}</span>
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            color: 'var(--text-muted)',
            fontSize: 13,
          }}
        >
          <Clock size={14} />
          <span
            className="mono"
            style={{
              fontFamily: 'Oxanium, sans-serif',
              fontWeight: 700,
              color: 'var(--text-primary)',
            }}
          >
            {formatDuration(totalDuration)}
          </span>
        </div>

        {isCompleted ? (
          <span className="badge badge-green">Ended</span>
        ) : (
          <button onClick={onEndSession} className="btn btn-secondary btn-sm">
            <Flag size={13} />
            End Session
          </button>
        )}
      </div>
    </div>
  )
}
