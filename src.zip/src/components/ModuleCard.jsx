import { useState } from 'react'
import { ChevronDown, GripVertical } from 'lucide-react'
import {
  DndContext,
  closestCenter,
  PointerSensor,
  KeyboardSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core'
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import DrillRow from './DrillRow.jsx'
import WeaponPicker from './WeaponPicker.jsx'
import ModuleManageMenu from './ModuleManageMenu.jsx'
import AddDrillModal from './AddDrillModal.jsx'
import CreateModuleModal from './CreateModuleModal.jsx'
import ConfirmModal from './ConfirmModal.jsx'
import { uid } from '../utils/helpers.js'

/**
 * Unified module card for BOTH default and custom modules.
 *
 * Drill-level actions (edit name / delete / duplicate) are now wired
 * through DrillRow's kebab menu — no more hover-overlay icons that
 * collided with the timer controls.
 */
export default function ModuleCard({
  module,
  defaultOpen = false,
  onUpdate,
  onDelete,
  onDuplicate,
  onReorderDrills,
  todayPlan,
}) {
  const [open, setOpen] = useState(defaultOpen)
  const [guns, setGuns] = useState([])

  /* Part of today's active training plan? */
  const planned = !!todayPlan?.planned

  /* Make THIS module a sortable item within Training.jsx's DndContext. */
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: module.id })

  const moduleStyle = {
    transform: CSS.Transform.toString(transform),
    transition,
  }

  /* DnD sensors for INNER drill list. */
  const drillSensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  )

  function handleDrillDragEnd(event) {
    const { active, over } = event
    if (!over || active.id === over.id) return
    const oldIndex = module.drills.findIndex(d => d.id === active.id)
    const newIndex = module.drills.findIndex(d => d.id === over.id)
    if (oldIndex < 0 || newIndex < 0) return
    const next = arrayMove(module.drills, oldIndex, newIndex)
    if (onReorderDrills) onReorderDrills(module.id, next)
    else onUpdate({ ...module, drills: next })
  }

  /* Modal states */
  const [renameOpen, setRenameOpen] = useState(false)
  const [addDrillOpen, setAddDrillOpen] = useState(false)
  const [editingDrill, setEditingDrill] = useState(null)
  const [deleteOpen, setDeleteOpen] = useState(false)
  const [deletingDrill, setDeletingDrill] = useState(null)

  function handleRename({ name, description, icon }) {
    onUpdate({
      ...module,
      name: name.trim() || module.name,
      short: name.trim() || module.short,
      description: description.trim(),
      icon: icon || module.icon,
    })
    setRenameOpen(false)
  }

  function handleAddDrill({ name, description }) {
    onUpdate({
      ...module,
      drills: [
        ...module.drills,
        {
          id: 'drill-' + uid(),
          name: name.trim(),
          description: description.trim(),
        },
      ],
    })
    setAddDrillOpen(false)
  }

  function handleEditDrill({ name, description }) {
    if (!editingDrill) return
    onUpdate({
      ...module,
      drills: module.drills.map(d =>
        d.id === editingDrill.id
          ? { ...d, name: name.trim(), description: description.trim() }
          : d
      ),
    })
    setEditingDrill(null)
  }

  function handleDuplicateDrill(drill) {
    onUpdate({
      ...module,
      drills: [
        ...module.drills,
        {
          id: 'drill-' + uid(),
          name: drill.name.endsWith(' (Copy)') ? drill.name : drill.name + ' (Copy)',
          description: drill.description || '',
        },
      ],
    })
  }

  function handleDeleteDrillConfirmed() {
    if (!deletingDrill) return
    onUpdate({
      ...module,
      drills: module.drills.filter(d => d.id !== deletingDrill.id),
    })
    setDeletingDrill(null)
  }

  return (
    <>
      <div
        ref={setNodeRef}
        style={moduleStyle}
        className={`glass clip-corner-sm overflow-hidden transition-all ${
          planned
            ? 'border border-accent-primary shadow-red-glow'
            : module.isDefault
            ? ''
            : 'border border-[rgba(232,0,28,0.2)]'
        } ${isDragging ? 'scale-[1.02] shadow-red-glow-lg z-10 relative' : ''}`}
      >
        {/* Header */}
        <div className="w-full flex items-center justify-between px-6 py-5 hover:bg-white/[0.03] transition-all">
          {/* Drag handle */}
          <button
            {...attributes}
            {...listeners}
            className="mr-1 -ml-2 p-1.5 rounded-md text-text-muted hover:text-accent-secondary hover:bg-white/5 transition-all cursor-grab active:cursor-grabbing touch-none flex-shrink-0"
            title="Drag to reorder module"
            aria-label="Drag to reorder module"
          >
            <GripVertical size={16} />
          </button>

          <button
            onClick={() => setOpen(v => !v)}
            className="flex items-center gap-4 text-left flex-1 min-w-0"
          >
            <div className="w-12 h-12 rounded-md bg-bg-elevated border border-border flex items-center justify-center text-2xl flex-shrink-0">
              {module.icon}
            </div>
            <div className="min-w-0">
              <div className="heading text-xl text-white tracking-wide flex items-center gap-2 flex-wrap">
                {module.name}
                {!module.isDefault && (
                  <span className="pill pill-red text-[10px] tracking-widest">CUSTOM</span>
                )}
              </div>
              {module.description && (
                <div className="text-sm text-text-secondary mt-0.5 truncate">
                  {module.description}
                </div>
              )}
              {planned && todayPlan.duration > 0 && (
                <div className="text-xs text-gold mt-1 flex items-center gap-1">
                  ⏱ {todayPlan.duration} mins planned
                </div>
              )}
            </div>
          </button>

          <div className="flex items-center gap-2 flex-shrink-0">
            {planned && (
              <span className="pill text-[10px] tracking-widest bg-[rgba(232,0,28,0.15)] border-[rgba(232,0,28,0.5)] text-accent-secondary shadow-red-glow whitespace-nowrap">
                📋 TODAY'S PLAN
              </span>
            )}
            <span className="pill pill-red text-xs mono">
              {module.drills.length} drill{module.drills.length === 1 ? '' : 's'}
            </span>
            <ModuleManageMenu
              onRename={() => setRenameOpen(true)}
              onAddDrill={() => setAddDrillOpen(true)}
              onDuplicate={() => onDuplicate?.()}
              onDelete={() => setDeleteOpen(true)}
            />
            <button
              onClick={() => setOpen(v => !v)}
              className="p-2 rounded-md text-text-secondary hover:text-white transition-all"
              title={open ? 'Collapse' : 'Expand'}
            >
              <ChevronDown
                size={18}
                className={`transition-transform ${open ? 'rotate-180 text-accent-secondary' : ''}`}
              />
            </button>
          </div>
        </div>

        {/* Body */}
        {open && (
          <div className="border-t border-border px-6 py-6 space-y-6 animate-fade-in">
            <WeaponPicker selected={guns} onChange={setGuns} />

            <div>
              <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                <div className="heading text-xs uppercase tracking-[0.18em] text-accent-secondary">
                  Drills
                </div>
                <button
                  onClick={() => setAddDrillOpen(true)}
                  className="text-xs heading uppercase tracking-widest text-accent-secondary hover:text-white transition-all flex items-center gap-1.5"
                >
                  + Add drill
                </button>
              </div>

              {module.drills.length === 0 ? (
                <div className="text-center py-10 px-4 border border-dashed border-border rounded-md">
                  <div className="text-3xl mb-2 opacity-70">🧩</div>
                  <p className="text-text-secondary text-sm">No drills yet.</p>
                  <p className="text-text-muted text-xs mt-1">
                    Add your first drill to start logging sessions.
                  </p>
                </div>
              ) : (
                <DndContext
                  sensors={drillSensors}
                  collisionDetection={closestCenter}
                  onDragEnd={handleDrillDragEnd}
                >
                  <SortableContext
                    items={module.drills.map(d => d.id)}
                    strategy={verticalListSortingStrategy}
                  >
                    <div className="space-y-3">
                      {module.drills.map(drill => (
                        <DrillRow
                          key={drill.id}
                          drill={drill}
                          moduleId={module.id}
                          moduleName={module.short || module.name}
                          gunsSelected={guns}
                          isCustom={!module.isDefault}
                          onEditDrill={d => setEditingDrill(d)}
                          onDeleteDrill={d => setDeletingDrill(d)}
                          onDuplicateDrill={d => handleDuplicateDrill(d)}
                        />
                      ))}
                    </div>
                  </SortableContext>
                </DndContext>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      <CreateModuleModal
        open={renameOpen}
        mode="edit"
        initial={{ name: module.name, description: module.description, icon: module.icon }}
        onClose={() => setRenameOpen(false)}
        onSubmit={handleRename}
      />

      <AddDrillModal
        open={addDrillOpen}
        mode="add"
        moduleName={module.name}
        onClose={() => setAddDrillOpen(false)}
        onSubmit={handleAddDrill}
      />

      <AddDrillModal
        open={!!editingDrill}
        mode="edit"
        moduleName={module.name}
        initial={editingDrill || undefined}
        onClose={() => setEditingDrill(null)}
        onSubmit={handleEditDrill}
      />

      <ConfirmModal
        open={deleteOpen}
        title={`Delete "${module.name}"?`}
        message={
          <>
            All drill history under this module will remain in your stats,
            but the module will be removed.
          </>
        }
        confirmLabel="Delete Module"
        onClose={() => setDeleteOpen(false)}
        onConfirm={() => { setDeleteOpen(false); onDelete?.() }}
      />

      <ConfirmModal
        open={!!deletingDrill}
        title="Delete drill?"
        message={
          <>
            Remove <strong className="text-white">"{deletingDrill?.name}"</strong> from this module.
            Logged sessions for this drill will remain in your history.
          </>
        }
        confirmLabel="Delete Drill"
        onClose={() => setDeletingDrill(null)}
        onConfirm={handleDeleteDrillConfirmed}
      />
    </>
  )
}
