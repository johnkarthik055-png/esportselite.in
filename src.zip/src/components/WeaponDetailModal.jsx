import { useEffect } from 'react'
import { X, Crosshair, Target, Sparkles, Lightbulb, Flame } from 'lucide-react'
import { getWeaponImage, INLINE_FALLBACK_IMAGE } from '../utils/weaponImages.js'

/**
 * Weapon detail modal — large image left, stats + damage table + tips right.
 * Closes via ESC, click outside, or the ✕ button.
 */
export default function WeaponDetailModal({ open, weapon, onClose }) {
  useEffect(() => {
    if (!open) return
    function onKey(e) {
      if (e.key === 'Escape') onClose?.()
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [open, onClose])

  if (!open || !weapon) return null

  const img = getWeaponImage(weapon.name)
  const rof = weapon.rateOfFire ? Math.round(60 / weapon.rateOfFire) : null

  return (
    <div
      className="fixed inset-0 z-50 flex items-stretch sm:items-center justify-center p-0 sm:p-4 bg-black/90 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full h-full sm:h-auto sm:max-w-3xl glass-strong sm:clip-corner border border-[rgba(232,0,28,0.4)] shadow-red-glow-lg animate-slide-in sm:max-h-[92vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        <div className="absolute -top-16 -right-16 w-56 h-56 bg-accent-primary opacity-[0.15] blur-3xl rounded-full pointer-events-none" />
        <div className="absolute top-0 left-0 w-full h-1 bg-red-gradient" />

        {/* Header */}
        <div className="relative z-10 flex items-start justify-between gap-3 px-6 py-5 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-md bg-red-gradient flex items-center justify-center shadow-red-glow">
              <Crosshair size={20} className="text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="heading text-2xl text-white tracking-wide">{weapon.name}</h3>
                <span className="pill pill-red text-[10px] heading uppercase tracking-widest">
                  {weapon.category}
                </span>
              </div>
              <p className="text-xs text-text-secondary uppercase tracking-widest mt-0.5 mono">
                🔴 {weapon.ammo}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-md text-text-secondary hover:text-accent-secondary hover:bg-white/5 transition-all"
            title="Close (Esc)"
          >
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="relative z-10 p-6 grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Image */}
          <div className="lg:col-span-2 flex items-center justify-center bg-bg-elevated/40 border border-border rounded-md p-6 min-h-[200px]">
            <img
              src={img}
              alt={weapon.name}
              onError={e => { e.currentTarget.src = INLINE_FALLBACK_IMAGE }}
              className="max-w-full max-h-60 object-contain"
            />
          </div>

          {/* Stats */}
          <div className="lg:col-span-3 space-y-5">
            <SectionTitle icon={<Sparkles size={14} />} label="Stats" />
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              <StatBadge label="Damage" value={weapon.damage || '—'} />
              <StatBadge label="DPS" value={weapon.dps || '—'} />
              <StatBadge label="Magazine" value={weapon.magazine ?? '—'} />
              <StatBadge label="Firing Mode" value={weapon.firingMode || '—'} small />
              <StatBadge label="Range" value={weapon.range || '—'} />
              <StatBadge label="Bullet Speed" value={weapon.bulletSpeed ? `${weapon.bulletSpeed} m/s` : '—'} />
              <StatBadge label="Rate of Fire" value={rof ? `${rof} rpm` : '—'} />
              <StatBadge label="ROF (s/shot)" value={weapon.rateOfFire ? `${weapon.rateOfFire.toFixed(2)}s` : '—'} />
            </div>

            <SectionTitle icon={<Target size={14} />} label="Damage Table (Level 2 Armor)" />
            <div className="grid grid-cols-2 gap-2">
              <DamageRow label="Body hits to kill" value={weapon.hitsToKill?.body ?? '—'} />
              <DamageRow label="Head hits to kill" value={weapon.hitsToKill?.head ?? '—'} />
            </div>
          </div>
        </div>

        {/* Tips */}
        {(weapon.tips?.beginner || weapon.tips?.pro) && (
          <div className="relative z-10 px-6 pb-6 space-y-3">
            <SectionTitle icon={<Lightbulb size={14} />} label="Tips" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {weapon.tips?.beginner && (
                <div className="rounded-md border border-success/40 bg-success/10 px-4 py-3">
                  <div className="flex items-center gap-2 text-success heading text-xs uppercase tracking-widest mb-1.5">
                    🟢 Beginner Tip
                  </div>
                  <p className="text-sm text-text-primary leading-relaxed">{weapon.tips.beginner}</p>
                </div>
              )}
              {weapon.tips?.pro && (
                <div className="rounded-md border border-accent-primary/50 bg-[rgba(232,0,28,0.08)] px-4 py-3">
                  <div className="flex items-center gap-2 text-accent-secondary heading text-xs uppercase tracking-widest mb-1.5">
                    <Flame size={12} /> Pro Tip
                  </div>
                  <p className="text-sm text-text-primary leading-relaxed">{weapon.tips.pro}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Recommended attachments */}
        {weapon.recommendedAttachments?.length > 0 && (
          <div className="relative z-10 px-6 pb-7 space-y-3">
            <SectionTitle icon={<Crosshair size={14} />} label="Recommended Attachments" />
            <div className="flex flex-wrap gap-2">
              {weapon.recommendedAttachments.map(a => (
                <span key={a} className="pill pill-red text-xs">
                  {a}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function SectionTitle({ icon, label }) {
  return (
    <div className="flex items-center gap-2 text-accent-secondary heading text-xs uppercase tracking-[0.18em]">
      {icon}
      {label}
    </div>
  )
}

function StatBadge({ label, value, small }) {
  return (
    <div className="rounded-md border border-border bg-bg-elevated/60 px-3 py-2 hover:border-accent-primary/40 transition-all">
      <div className="heading text-[10px] uppercase tracking-widest text-text-muted">{label}</div>
      <div className={`mono mt-0.5 ${small ? 'text-xs' : 'text-base'} text-accent-secondary`}>
        {value}
      </div>
    </div>
  )
}

function DamageRow({ label, value }) {
  return (
    <div className="flex items-center justify-between px-3 py-2 rounded-md border border-border bg-bg-elevated/40">
      <span className="text-xs heading uppercase tracking-widest text-text-secondary">
        {label}
      </span>
      <span className="mono text-base text-accent-secondary">{value}</span>
    </div>
  )
}
