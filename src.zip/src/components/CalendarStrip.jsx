import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import {
  Calendar as CalendarIcon,
  Activity,
  Trophy,
  StickyNote,
  Sparkles,
} from 'lucide-react'
import {
  STATUS_COLORS,
  SESSION_MOODS,
  MATCH_PERFORMANCES,
} from '../utils/constants.js'
import {
  dateKey,
  todayKey,
  formatDateFull,
  formatDuration,
} from '../utils/helpers.js'
import { useDailySessions, useDailyMatches } from '../hooks/useDailySessions.js'

const DOW_LETTERS = ['S', 'M', 'T', 'W', 'T', 'F', 'S'] // Sun-Sat indexable by getDay()

/**
 * Compact 14-day calendar strip used inside the Training Center.
 * Replaces the full month CalendarPicker but keeps the day-summary panel
 * below so clicking a date still loads its session data.
 *
 *  Props:
 *   - context: 'training' | 'matches'  (which surface controls the dot)
 *   - onTodayAction(): clicking the "Start a Drill" CTA in summary
 */
export default function CalendarStrip({ context = 'training', onTodayAction }) {
  const sessions = useDailySessions()
  const matches = useDailyMatches()

  const today = todayKey()
  const [searchParams] = useSearchParams()
  const urlDate = searchParams.get('date')
  const initialDate =
    urlDate && /^\d{4}-\d{2}-\d{2}$/.test(urlDate) ? urlDate : today

  const [selected, setSelected] = useState(initialDate)

  /* Keep selected in sync with deep links (e.g. Dashboard mini-strip). */
  useEffect(() => {
    if (urlDate && /^\d{4}-\d{2}-\d{2}$/.test(urlDate)) {
      setSelected(urlDate)
    }
  }, [urlDate])

  /* Build 14 chronological days ending today. */
  const days = useMemo(() => {
    const out = []
    const now = new Date()
    for (let i = 13; i >= 0; i--) {
      const d = new Date(now)
      d.setDate(now.getDate() - i)
      out.push(d)
    }
    return out
  }, [])

  function getDotStatus(d) {
    return context === 'training'
      ? sessions.getStatusForDate(d)
      : matches.getStatusForDate(d)
  }

  return (
    <div className="glass clip-corner-sm p-5 relative overflow-hidden">
      <div className="absolute -top-12 -right-12 w-40 h-40 rounded-full bg-accent-primary opacity-[0.08] blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="relative z-10 flex items-center justify-between mb-3 flex-wrap gap-2">
        <h3 className="heading text-sm uppercase tracking-[0.18em] text-white flex items-center gap-2">
          <CalendarIcon size={14} className="text-accent-secondary" /> LAST 14 DAYS
        </h3>
        <span className="text-[10px] heading uppercase tracking-widest text-text-muted">
          {context === 'training' ? 'Training calendar' : 'Match calendar'}
        </span>
      </div>

      {/* Strip — horizontally scrollable on mobile */}
      <div className="relative z-10 -mx-1 overflow-x-auto">
        <div
          className="grid gap-1 px-1 min-w-[560px] sm:min-w-0"
          style={{ gridTemplateColumns: 'repeat(14, minmax(36px, 1fr))' }}
        >
        {days.map(d => {
          const key = dateKey(d)
          const isToday = key === today
          const isSelected = key === selected
          const status = getDotStatus(key)
          const dotColor = STATUS_COLORS[status]
          const showDot = dotColor && dotColor !== 'transparent'
          return (
            <button
              key={key}
              onClick={() => setSelected(key)}
              className={`flex flex-col items-center gap-1 py-1.5 rounded-md transition-all border ${
                isSelected
                  ? 'border-accent-primary bg-[rgba(232,0,28,0.08)]'
                  : 'border-transparent hover:bg-white/[0.04]'
              }`}
              title={`${key} • ${status.replace('_', ' ')}`}
            >
              <span className="text-[10px] heading uppercase tracking-widest text-text-muted">
                {DOW_LETTERS[d.getDay()]}
              </span>
              {showDot ? (
                <span
                  className={`block w-2.5 h-2.5 rounded-full ${isToday ? 'animate-pulse-red' : ''}`}
                  style={{
                    background: dotColor,
                    boxShadow:
                      status === 'completed' || isToday ? `0 0 6px ${dotColor}` : 'none',
                  }}
                />
              ) : (
                <span className="block w-2.5 h-2.5 rounded-full border border-text-muted/40" />
              )}
              <span
                className={`mono text-[11px] ${isToday ? 'text-white' : 'text-text-secondary'}`}
              >
                {d.getDate()}
              </span>
            </button>
          )
        })}
        </div>
      </div>

      {/* Legend */}
      <div className="relative z-10 mt-3 flex items-center justify-center gap-4 flex-wrap text-[10px] uppercase tracking-widest heading text-text-secondary">
        <LegendDot color={STATUS_COLORS.completed} label="Completed" />
        <LegendDot color={STATUS_COLORS.incomplete} label="Incomplete" />
        <LegendDot color={STATUS_COLORS.not_completed} label="Missed" />
        <LegendDot color={STATUS_COLORS.in_progress} label="Today" pulse />
      </div>

      {/* Day Summary */}
      <div className="relative z-10 mt-4">
        <DaySummary
          date={selected}
          context={context}
          sessions={sessions}
          matches={matches}
          onTodayAction={onTodayAction}
        />
      </div>
    </div>
  )
}

function LegendDot({ color, label, pulse }) {
  return (
    <span className="flex items-center gap-1.5">
      <span
        className={`w-2 h-2 rounded-full inline-block ${pulse ? 'animate-pulse-red' : ''}`}
        style={{ background: color, boxShadow: `0 0 6px ${color}` }}
      />
      {label}
    </span>
  )
}

/* ============================================================
   DAY SUMMARY PANEL — same shape as the one in CalendarPicker
   so users get the same data when they click a dot.
   ============================================================ */
function DaySummary({ date, context, sessions, matches, onTodayAction }) {
  const today = todayKey()
  const isToday = date === today
  const isFuture = date > today
  if (isFuture) return null

  const sStatus = sessions.getStatusForDate(date)
  const mStatus = matches.getStatusForDate(date)
  const sEntry = sessions.getEntry(date)
  const mEntry = matches.getEntry(date)
  const sActivity = sessions.getDayActivity(date)
  const mActivity = matches.getDayActivity(date)

  const headerStatus = context === 'training' ? sStatus : mStatus
  const statusColor = STATUS_COLORS[headerStatus]
  const statusLabel =
    headerStatus === 'completed'
      ? 'Completed'
      : headerStatus === 'incomplete'
      ? 'Incomplete'
      : headerStatus === 'in_progress'
      ? 'In Progress'
      : headerStatus === 'not_started'
      ? 'Not Started'
      : 'Not Completed'

  const mood = sEntry?.mood ? SESSION_MOODS.find(m => m.id === sEntry.mood) : null
  const performance = mEntry?.performance
    ? MATCH_PERFORMANCES.find(p => p.id === mEntry.performance)
    : null

  return (
    <div className="rounded-md border border-border bg-bg-elevated/40 overflow-hidden animate-fade-in">
      <div className="flex items-center justify-between gap-3 flex-wrap px-5 py-4 border-b border-border bg-bg-primary/30">
        <div className="flex items-center gap-3">
          <CalendarIcon size={16} className="text-accent-secondary" />
          <span className="heading text-base text-white tracking-wide">
            {formatDateFull(date)}
          </span>
        </div>
        <span
          className="pill text-xs heading uppercase tracking-widest"
          style={{
            background: `${statusColor}22`,
            borderColor: `${statusColor}66`,
            color: statusColor,
          }}
        >
          ● {statusLabel}
        </span>
      </div>

      <div className="p-5 space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <SummaryBlock
            icon={<Activity size={16} />}
            title="Training"
            empty={sActivity.drillCount === 0 ? 'No drills logged' : null}
          >
            {sActivity.drillCount > 0 && (
              <>
                <Row
                  label="Drills"
                  value={`${sActivity.drillCount} • ${formatDuration(sActivity.totalDuration)}`}
                />
                {mood && (
                  <Row
                    label="Mood"
                    value={
                      <span className="text-white">
                        {mood.emoji} {mood.label}
                      </span>
                    }
                  />
                )}
                {sActivity.modulesWorked.length > 0 && (
                  <div className="pt-1">
                    <div className="text-[10px] uppercase tracking-widest heading text-text-muted mb-1.5">
                      Modules
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {sActivity.modulesWorked.map(m => (
                        <span key={m} className="pill text-[10px]">
                          {m}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </SummaryBlock>

          <SummaryBlock
            icon={<Trophy size={16} />}
            title="Matches"
            empty={mActivity.matchCount === 0 ? 'No matches logged' : null}
          >
            {mActivity.matchCount > 0 && (
              <>
                <Row label="Logged" value={`${mActivity.matchCount}`} />
                {performance && (
                  <Row
                    label="Performance"
                    value={
                      <span className="text-white">
                        {performance.emoji} {performance.label}
                      </span>
                    }
                  />
                )}
                {mEntry?.takeaway && (
                  <div className="pt-1">
                    <div className="text-[10px] uppercase tracking-widest heading text-text-muted mb-1.5 flex items-center gap-1">
                      <StickyNote size={11} /> Takeaway
                    </div>
                    <p className="text-xs text-text-secondary italic leading-relaxed">
                      "{mEntry.takeaway}"
                    </p>
                  </div>
                )}
              </>
            )}
          </SummaryBlock>
        </div>

        {sEntry?.notes && (
          <div className="rounded-md border border-border bg-bg-primary/30 px-4 py-3">
            <div className="text-[10px] uppercase tracking-widest heading text-text-muted mb-1.5 flex items-center gap-1">
              <StickyNote size={11} /> Session notes
            </div>
            <p className="text-sm text-text-secondary italic leading-relaxed">
              "{sEntry.notes}"
            </p>
          </div>
        )}

        {isToday && headerStatus !== 'completed' && onTodayAction && (
          <div className="pt-1">
            <button
              onClick={onTodayAction}
              className="btn-red px-4 py-2.5 rounded-md text-xs uppercase tracking-[0.15em] flex items-center gap-2"
            >
              <Sparkles size={14} />
              {context === 'training' ? 'Start a Drill' : 'Log a Match'}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

function SummaryBlock({ icon, title, children, empty }) {
  return (
    <div className="rounded-md border border-border bg-bg-primary/30 px-4 py-3 space-y-2">
      <div className="flex items-center gap-2 text-text-secondary">
        {icon}
        <span className="heading text-xs uppercase tracking-widest">{title}</span>
      </div>
      {empty ? (
        <p className="text-xs text-text-muted italic">{empty}</p>
      ) : (
        <div className="space-y-1.5">{children}</div>
      )}
    </div>
  )
}

function Row({ label, value }) {
  return (
    <div className="flex items-center justify-between gap-3 text-sm">
      <span className="text-text-muted text-xs uppercase tracking-widest heading">{label}</span>
      <span className="mono text-accent-secondary">{value}</span>
    </div>
  )
}
