import { useState, useEffect } from 'react'
import { ChevronDown, X, Crosshair } from 'lucide-react'
import { WEAPON_CATEGORIES } from '../utils/constants.js'

/**
 * Categorized weapon picker.
 * Controlled: `selected` is an ordered array (oldest first).
 *
 * Rules:
 *  - Up to 2 weapons selected simultaneously
 *  - Selecting a 3rd auto-removes the OLDEST and shows a toast
 *  - AR category expanded by default; others collapsed
 *  - Selected weapons render as removable chips above the picker
 */
export default function WeaponPicker({ selected = [], onChange }) {
  const [expanded, setExpanded] = useState(() => new Set(['AR']))
  const [toast, setToast] = useState('')

  useEffect(() => {
    if (!toast) return
    const t = setTimeout(() => setToast(''), 2400)
    return () => clearTimeout(t)
  }, [toast])

  function toggleCategory(id) {
    setExpanded(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  function toggleGun(weapon) {
    const isSelected = selected.includes(weapon)
    if (isSelected) {
      onChange(selected.filter(g => g !== weapon))
      return
    }
    if (selected.length < 2) {
      onChange([...selected, weapon])
      return
    }
    /* Already 2 selected — replace the oldest. */
    const oldest = selected[0]
    onChange([selected[1], weapon])
    setToast(`Max 2 weapons. Replaced ${oldest}.`)
  }

  function removeGun(weapon) {
    onChange(selected.filter(g => g !== weapon))
  }

  return (
    <div className="border border-border rounded-md bg-bg-elevated/40 overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 border-b border-border bg-bg-elevated/60 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Crosshair size={16} className="text-accent-secondary" />
          <span className="heading text-sm tracking-[0.2em] uppercase text-white">Weapons</span>
          <span className="text-xs text-text-secondary">
            (select up to 2)
          </span>
        </div>

        {/* Selected chip strip */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs uppercase tracking-widest heading text-text-muted">
            Selected:
          </span>
          {selected.length === 0 ? (
            <span className="text-xs text-text-secondary italic">none</span>
          ) : (
            selected.map(g => (
              <button
                key={g}
                onClick={() => removeGun(g)}
                className="pill pill-red mono text-xs hover:bg-[rgba(232,0,28,0.2)] transition-all flex items-center gap-1.5"
                title="Remove"
              >
                {g} <X size={12} />
              </button>
            ))
          )}
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div className="px-4 py-2 bg-warning/15 border-b border-warning/30 text-warning text-xs mono flex items-center gap-2 animate-fade-in">
          ⚠ {toast}
        </div>
      )}

      {/* Categories */}
      <div className="divide-y divide-border">
        {WEAPON_CATEGORIES.map(cat => {
          const isOpen = expanded.has(cat.id)
          const selectedInCat = cat.weapons.filter(w => selected.includes(w)).length
          return (
            <div key={cat.id}>
              <button
                onClick={() => toggleCategory(cat.id)}
                className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/[0.03] transition-all text-left"
              >
                <div className="flex items-center gap-3">
                  <ChevronDown
                    size={16}
                    className={`text-text-secondary transition-transform ${isOpen ? 'rotate-0 text-accent-secondary' : '-rotate-90'}`}
                  />
                  <span className="heading text-sm uppercase tracking-[0.15em] text-white">
                    {cat.label}
                  </span>
                  <span className="text-xs text-text-muted">({cat.short})</span>
                </div>
                <div className="flex items-center gap-3">
                  {selectedInCat > 0 && (
                    <span className="pill pill-red text-[10px] mono">
                      {selectedInCat} active
                    </span>
                  )}
                  <span className="text-xs text-text-muted mono">{cat.weapons.length}</span>
                </div>
              </button>

              {isOpen && (
                <div className="px-4 pb-4 pt-1 animate-fade-in">
                  <div className="flex flex-wrap gap-2">
                    {cat.weapons.map(w => {
                      const active = selected.includes(w)
                      return (
                        <button
                          key={w}
                          onClick={() => toggleGun(w)}
                          className={`gun-pill ${active ? 'active' : ''}`}
                        >
                          {w}
                        </button>
                      )
                    })}
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
