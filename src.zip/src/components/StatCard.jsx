export default function StatCard({
  icon,
  value,
  label,
  sub,
  accent,
  progress,
  monoValue,
  wrapperClass = '',
  wrapperStyle,
}) {
  const accentClass = accent === 'gold'
    ? 'text-gold'
    : accent === 'red'
    ? 'text-accent-secondary'
    : 'text-white'

  return (
    <div
      className={`glass clip-corner-sm p-5 relative overflow-hidden group hover:border-accent-primary transition-all ${wrapperClass}`}
      style={wrapperStyle}
    >
      <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full bg-accent-primary opacity-0 group-hover:opacity-10 blur-2xl transition-opacity" />

      <div className="flex items-start justify-between mb-3 relative z-10">
        <div className="text-2xl">{icon}</div>
        {accent === 'gold' && (
          <span className="pill bg-[rgba(255,215,0,0.1)] border-[rgba(255,215,0,0.3)] text-gold text-[10px] uppercase tracking-widest">
            On Fire
          </span>
        )}
      </div>

      <div className={`heading text-3xl lg:text-4xl ${accentClass} ${monoValue ? 'mono' : ''} tracking-wide relative z-10`}>
        {value}
      </div>
      <div className="heading text-xs uppercase tracking-[0.18em] text-text-secondary mt-2 relative z-10">
        {label}
      </div>
      <div className="text-xs text-text-muted mt-1 relative z-10">{sub}</div>

      {typeof progress === 'number' && (
        <div className="mt-4 relative z-10">
          <div className="h-1.5 w-full bg-bg-elevated rounded-full overflow-hidden">
            <div
              className="h-full bg-red-gradient transition-all duration-500 shadow-red-glow"
              style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
            />
          </div>
        </div>
      )}
    </div>
  )
}
