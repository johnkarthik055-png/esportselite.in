import ComingSoon from '../components/ComingSoon.jsx'

export default function Progress() {
  return <ComingSoon title="Progress" />
}
