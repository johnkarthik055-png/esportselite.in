import ComingSoon from '../components/ComingSoon.jsx'

export default function Analytics() {
  return <ComingSoon title="Analytics" />
}
