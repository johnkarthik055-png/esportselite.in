import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { ClipboardList, Bot, Plus, Save, X, Sparkles } from 'lucide-react'
import { useLocalStorage } from '../hooks/useLocalStorage.js'
import { useModules } from '../hooks/useModules.js'
import { STORAGE_KEYS } from '../utils/constants.js'
import { uid } from '../utils/helpers.js'
import PlanCard from '../components/PlanCard.jsx'
import AIPlanGenerator from '../components/AIPlanGenerator.jsx'
import ConfirmModal from '../components/ConfirmModal.jsx'

/* esportselite_training_plans is local to this feature — inline key. */
const PLANS_KEY = 'esportselite_training_plans'

const DAY_FULL = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday',
]

const TABS = [
  { id: 'my', label: 'My Plan', icon: ClipboardList },
  { id: 'ai', label: 'AI Suggested', icon: Bot },
]

const DURATION_PRESETS = [7, 14, 30]

function buildEmptyDays() {
  return DAY_FULL.map((name, idx) => ({
    dayIndex: idx,
    dayName: name,
    isRestDay: false,
    sessions: [],
    matchPractice: false,
    notes: '',
    dailyTip: '',
  }))
}

function todayISODate() {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
    d.getDate()
  ).padStart(2, '0')}`
}

export default function TrainingPlan() {
  const [tab, setTab] = useState('my')
  const [plans, setPlans] = useLocalStorage(PLANS_KEY, [])
  const [dailySessions] = useLocalStorage(STORAGE_KEYS.DAILY_SESSIONS, {})
  const { modules } = useModules()

  const [modalOpen, setModalOpen] = useState(false)
  const [editingPlan, setEditingPlan] = useState(null)
  const [confirmDeleteId, setConfirmDeleteId] = useState(null)

  /* ---- CRUD ---- */
  function addPlan(plan) {
    setPlans(prev => {
      const isFirst = prev.length === 0
      const entry = { ...plan, isActive: plan.isActive || isFirst }
      /* If this one is active, deactivate the rest. */
      const next = entry.isActive
        ? prev.map(p => ({ ...p, isActive: false }))
        : prev.slice()
      return [entry, ...next]
    })
  }

  function updatePlan(updated) {
    setPlans(prev => prev.map(p => (p.id === updated.id ? updated : p)))
  }

  function deletePlan(id) {
    setPlans(prev => prev.filter(p => p.id !== id))
  }

  function duplicatePlan(id) {
    setPlans(prev => {
      const orig = prev.find(p => p.id === id)
      if (!orig) return prev
      const copy = {
        ...orig,
        id: 'plan-' + uid(),
        name: orig.name.endsWith(' (Copy)') ? orig.name : orig.name + ' (Copy)',
        isActive: false,
        createdAt: Date.now(),
        days: (orig.days || []).map(d => ({
          ...d,
          sessions: (d.sessions || []).map(s => ({ ...s, id: 'sess-' + uid() })),
        })),
      }
      return [copy, ...prev]
    })
  }

  function setActivePlan(id) {
    setPlans(prev => prev.map(p => ({ ...p, isActive: p.id === id })))
  }

  /* ---- Create / Edit modal handlers ---- */
  function openCreate() {
    setEditingPlan(null)
    setModalOpen(true)
  }

  function openEdit(plan) {
    setEditingPlan(plan)
    setModalOpen(true)
  }

  function submitModal({ name, goal, duration, startDate }) {
    if (editingPlan) {
      updatePlan({ ...editingPlan, name, goal, duration, startDate })
    } else {
      addPlan({
        id: 'plan-' + uid(),
        name,
        goal,
        duration,
        startDate,
        isActive: false,
        isAiGenerated: false,
        createdAt: Date.now(),
        days: buildEmptyDays(),
        overallTip: '',
      })
    }
    setModalOpen(false)
    setEditingPlan(null)
  }

  const planToDelete = plans.find(p => p.id === confirmDeleteId)

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="glass clip-corner p-4 sm:p-6 lg:p-8 relative overflow-hidden">
        <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-accent-primary opacity-[0.1] blur-[100px]" />
        <div className="relative z-10">
          <h2 className="heading text-xl sm:text-2xl lg:text-3xl text-white tracking-wide">
            Training <span className="text-gradient-red">Plan</span>
          </h2>
          <p className="text-text-secondary mt-2 max-w-2xl text-sm sm:text-base">
            Build your own weekly routine or let the AI coach craft a personalized plan
            from your match data.
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-border overflow-x-auto whitespace-nowrap -mx-4 px-4 sm:mx-0 sm:px-0">
        {TABS.map(t => {
          const Icon = t.icon
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`tab-btn flex items-center gap-2 flex-shrink-0 ${
                tab === t.id ? 'active' : ''
              }`}
            >
              <Icon size={16} /> {t.label}
            </button>
          )
        })}
      </div>

      {/* Tab content */}
      {tab === 'my' ? (
        <div className="space-y-6">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h3 className="heading text-xl text-white tracking-wide flex items-center gap-2">
                <ClipboardList size={20} className="text-accent-secondary" /> MY TRAINING PLAN
              </h3>
              <p className="text-xs text-text-secondary uppercase tracking-widest mt-1">
                Build your weekly routine
              </p>
            </div>
            <button
              onClick={openCreate}
              className="btn-red px-5 py-2.5 rounded-md text-sm uppercase tracking-[0.15em] flex items-center gap-2"
            >
              <Plus size={16} /> Create New Plan
            </button>
          </div>

          {plans.length === 0 ? (
            <div className="glass clip-corner-sm p-10 text-center border border-dashed border-border">
              <Sparkles className="inline-block text-accent-secondary" size={42} />
              <h4 className="heading text-lg text-white mt-3">No plans yet</h4>
              <p className="text-text-secondary text-sm mt-1 max-w-md mx-auto">
                Create your first weekly training plan, or generate one with the AI coach.
              </p>
              <div className="mt-5 flex items-center justify-center gap-3 flex-wrap">
                <button
                  onClick={openCreate}
                  className="btn-red px-4 py-2.5 rounded-md text-xs uppercase tracking-[0.15em] flex items-center gap-2"
                >
                  <Plus size={14} /> Create plan
                </button>
                <button
                  onClick={() => setTab('ai')}
                  className="btn-outline px-4 py-2.5 rounded-md text-xs uppercase tracking-[0.15em] flex items-center gap-2"
                >
                  <Bot size={14} /> Try AI generator
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              {plans.map(plan => (
                <PlanCard
                  key={plan.id}
                  plan={plan}
                  dailySessions={dailySessions}
                  modules={modules}
                  onUpdate={updatePlan}
                  onDelete={id => setConfirmDeleteId(id)}
                  onDuplicate={duplicatePlan}
                  onSetActive={setActivePlan}
                  onEdit={openEdit}
                />
              ))}
            </div>
          )}
        </div>
      ) : (
        <AIPlanGenerator onSavePlan={addPlan} />
      )}

      {/* Create / Edit modal */}
      <PlanFormModal
        open={modalOpen}
        initial={editingPlan}
        onClose={() => {
          setModalOpen(false)
          setEditingPlan(null)
        }}
        onSubmit={submitModal}
      />

      {/* Delete confirm */}
      <ConfirmModal
        open={!!confirmDeleteId}
        title="Delete plan?"
        message={
          planToDelete ? (
            <>
              Delete <span className="text-white font-medium">{planToDelete.name}</span>?
              This cannot be undone.
            </>
          ) : (
            'Delete this plan?'
          )
        }
        confirmLabel="Delete"
        onClose={() => setConfirmDeleteId(null)}
        onConfirm={() => {
          deletePlan(confirmDeleteId)
          setConfirmDeleteId(null)
        }}
      />
    </div>
  )
}

/* ============================================================
   CREATE / EDIT PLAN MODAL
   Rendered through a portal to document.body so it floats above
   everything (same overlay treatment as DayEditor).
   ============================================================ */
function PlanFormModal({ open, initial, onClose, onSubmit }) {
  const [name, setName] = useState('')
  const [goal, setGoal] = useState('')
  const [durationMode, setDurationMode] = useState(7)
  const [customDuration, setCustomDuration] = useState(7)
  const [startDate, setStartDate] = useState(todayISODate())
  const [error, setError] = useState('')

  useEffect(() => {
    if (open) {
      setName(initial?.name || '')
      setGoal(initial?.goal || '')
      const dur = initial?.duration || 7
      if (DURATION_PRESETS.includes(dur)) {
        setDurationMode(dur)
      } else {
        setDurationMode('custom')
        setCustomDuration(dur)
      }
      setStartDate(
        initial?.startDate
          ? new Date(initial.startDate).toISOString().slice(0, 10)
          : todayISODate()
      )
      setError('')
    }
  }, [open, initial])

  useEffect(() => {
    if (!open) return
    function onKey(e) {
      if (e.key === 'Escape') onClose?.()
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [open, onClose])

  /* Lock body scroll while open. */
  useEffect(() => {
    if (!open) return
    const original = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = original
    }
  }, [open])

  if (!open || typeof document === 'undefined') return null

  function submit() {
    const trimmed = name.trim()
    if (!trimmed) {
      setError('Plan name is required.')
      return
    }
    const duration =
      durationMode === 'custom'
        ? Math.max(1, Math.min(365, Number(customDuration) || 7))
        : durationMode
    onSubmit({
      name: trimmed,
      goal: goal.trim(),
      duration,
      startDate: new Date(startDate + 'T00:00:00').toISOString(),
    })
  }

  const modal = (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 animate-fade-in"
      style={{ background: 'rgba(0,0,0,0.75)' }}
      onClick={onClose}
    >
      <div
        className="relative w-full h-full sm:h-auto sm:w-[560px] sm:max-w-[560px] sm:max-h-[85vh] overflow-y-auto bg-bg-elevated border border-[rgba(232,0,28,0.3)] sm:rounded-xl shadow-red-glow-lg animate-slide-in flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-border sticky top-0 bg-bg-elevated z-10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-red-gradient flex items-center justify-center shadow-red-glow">
              <ClipboardList size={18} className="text-white" />
            </div>
            <div>
              <h3 className="heading text-xl text-white tracking-wide">
                {initial ? 'Edit Plan' : 'Create New Plan'}
              </h3>
              <p className="text-xs text-text-secondary uppercase tracking-widest mt-0.5">
                Weekly routine
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-md text-text-secondary hover:text-white hover:bg-white/5 transition-all"
            title="Close"
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5 flex-1">
          <div>
            <label className="block text-xs uppercase tracking-[0.15em] text-text-secondary mb-2 heading">
              Plan Name
            </label>
            <input
              type="text"
              value={name}
              onChange={e => {
                setName(e.target.value)
                setError('')
              }}
              placeholder="e.g. Week 1 — Aim Focus"
              className="input-field"
              autoFocus
              maxLength={60}
            />
          </div>

          <div>
            <label className="block text-xs uppercase tracking-[0.15em] text-text-secondary mb-2 heading">
              Goal <span className="text-text-muted normal-case">(optional)</span>
            </label>
            <input
              type="text"
              value={goal}
              onChange={e => setGoal(e.target.value)}
              placeholder="e.g. Improve mid-range spray"
              className="input-field"
              maxLength={120}
            />
          </div>

          <div>
            <label className="block text-xs uppercase tracking-[0.15em] text-text-secondary mb-2 heading">
              Duration
            </label>
            <div className="flex gap-2 flex-wrap">
              {DURATION_PRESETS.map(d => (
                <button
                  key={d}
                  onClick={() => setDurationMode(d)}
                  className={
                    'px-4 py-2 rounded-full text-xs uppercase tracking-widest heading transition-all ' +
                    (durationMode === d
                      ? 'bg-red-gradient text-white shadow-red-glow'
                      : 'bg-bg-surface/60 border border-border text-text-secondary hover:text-white hover:border-accent-primary')
                  }
                >
                  {d} Days
                </button>
              ))}
              <button
                onClick={() => setDurationMode('custom')}
                className={
                  'px-4 py-2 rounded-full text-xs uppercase tracking-widest heading transition-all ' +
                  (durationMode === 'custom'
                    ? 'bg-red-gradient text-white shadow-red-glow'
                    : 'bg-bg-surface/60 border border-border text-text-secondary hover:text-white hover:border-accent-primary')
                }
              >
                Custom
              </button>
            </div>
            {durationMode === 'custom' && (
              <div className="mt-3 flex items-center gap-2">
                <input
                  type="number"
                  min="1"
                  max="365"
                  value={customDuration}
                  onChange={e => setCustomDuration(e.target.value)}
                  className="input-field w-28 text-center"
                />
                <span className="text-xs text-text-secondary">days</span>
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs uppercase tracking-[0.15em] text-text-secondary mb-2 heading">
              Start Date
            </label>
            <input
              type="date"
              value={startDate}
              onChange={e => setStartDate(e.target.value)}
              className="input-field"
            />
          </div>

          {error && (
            <div className="text-sm text-accent-secondary bg-[rgba(232,0,28,0.08)] border border-[rgba(232,0,28,0.3)] rounded-md px-3 py-2">
              {error}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-5 border-t border-border bg-bg-elevated sticky bottom-0 z-10">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-md text-sm uppercase tracking-[0.15em] heading font-semibold text-text-secondary hover:text-white border border-border hover:border-text-secondary transition-all"
          >
            Cancel
          </button>
          <button
            onClick={submit}
            className="btn-red px-5 py-2.5 rounded-md text-sm uppercase tracking-[0.15em] flex items-center gap-2"
          >
            <Save size={15} /> {initial ? 'Save Changes' : 'Create Plan'}
          </button>
        </div>
      </div>
    </div>
  )

  return createPortal(modal, document.body)
}
