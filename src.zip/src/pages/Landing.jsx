import { useState, useEffect, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Menu, X, Swords, Target, BarChart2, Brain, Crosshair, Zap, Users,
  UserPlus, TrendingUp, ArrowRight, Star, Check, Gift,
  Instagram, Youtube, Twitter, MessageCircle, Shield,
} from 'lucide-react'
import {
  collection, collectionGroup, getCountFromServer,
  getDocs, query, where, addDoc, serverTimestamp,
} from 'firebase/firestore'
import { db } from '../utils/firebase.js'

/* ============================================================
   ESPORTS ELITE — PUBLIC LANDING (redesigned)
   ============================================================ */

const NAV_ITEMS = [
  { label: 'Features',     id: 'features' },
  { label: 'How it works', id: 'how-it-works' },
  { label: 'Pricing',      id: 'pricing' },
]

const FEATURES = [
  { icon: Target,    accent: 'var(--blue)',  title: 'Practice Tracker',   desc: 'Log every drill with timers. Track ADS, spray, close range across custom modules.' },
  { icon: BarChart2, accent: 'var(--blue)',  title: 'Match Analytics',    desc: 'Log classic, scrims, and tournament matches. Track kills, positions, weaknesses.' },
  { icon: Brain,     accent: 'var(--amber)', title: 'Coach AI',           desc: 'Smart suggestions based on your repeated weaknesses. Know what to practice next.' },
  { icon: Crosshair, accent: 'var(--gold)',  title: 'Weakness Heatmap',   desc: 'Visual skill bars show exactly where you need work. Color-coded, data-driven.' },
  { icon: Zap,       accent: 'var(--green)', title: 'XP & Levels',        desc: 'Earn XP for every drill and match. Level up from Rookie to Elite across 7 tiers.' },
  { icon: Users,     accent: 'var(--text-muted)', title: 'Squad Ready',   desc: 'Team management, scrim scheduling, squad coordination — coming soon.' },
]

const STEPS = [
  { icon: UserPlus,   num: '01', title: 'Create account',  desc: 'Free 90-day access. No credit card required.' },
  { icon: Target,     num: '02', title: 'Start training',  desc: 'Pick a module, set your weapons, run the drill timer.' },
  { icon: TrendingUp, num: '03', title: 'Analyse & improve', desc: 'See your weaknesses, follow Coach AI tips, climb the ranks.' },
]

const TESTIMONIALS = [
  { quote: 'Finally a proper training tracker for BGMI. My spray control improved in 2 weeks.', name: 'ProSniper_X',      tier: 'Competitive Player' },
  { quote: 'The weakness heatmap is insane. I never knew my close range was that weak.',       name: 'EliteGrinder99',   tier: 'Solo Ranked' },
  { quote: 'Coach AI told me to focus on spray. My K/D went from 2.1 to 3.4. This app works.', name: 'BulletStorm_IN',   tier: 'Squad Player' },
]

const PRICING_PERKS = [
  'All training modules',
  'Match logger',
  'Weakness heatmap',
  'Coach AI analysis',
  'XP & level system',
  'Cloud data sync',
]

/* ============================================================
   HOOKS
   ============================================================ */
function useInView(threshold = 0.15) {
  const ref = useRef(null)
  const [inView, setInView] = useState(false)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { setInView(true); obs.unobserve(el) }
    }, { threshold })
    obs.observe(el)
    return () => obs.disconnect()
    /* eslint-disable-next-line react-hooks/exhaustive-deps */
  }, [])
  return [ref, inView]
}

function formatNum(n) {
  if (n >= 1000) {
    const k = n / 1000
    return (k >= 10 ? Math.round(k) : Math.round(k * 10) / 10) + 'K'
  }
  return String(Math.round(n))
}

function useCountUp(target, active, duration = 1500) {
  const [val, setVal] = useState(0)
  useEffect(() => {
    if (!active) return
    let raf
    const start = performance.now()
    const tick = (now) => {
      const p = Math.min((now - start) / duration, 1)
      const eased = 1 - Math.pow(1 - p, 3)
      setVal(eased * target)
      if (p < 1) raf = requestAnimationFrame(tick)
      else setVal(target)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [active, target, duration])
  return val
}

/* ============================================================
   MAIN
   ============================================================ */
export default function Landing() {
  const navigate = useNavigate()
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  const goLogin  = () => navigate('/login')
  const goSignup = () => navigate('/login', { state: { signup: true } })

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll, { passive: true })
    onScroll()
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const scrollTo = useCallback((id) => {
    setMenuOpen(false)
    const el = document.getElementById(id)
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }, [])

  return (
    <div style={{ background: 'var(--bg-base)', color: 'var(--text-primary)', minHeight: '100vh', overflowX: 'hidden' }}>
      <Navbar scrolled={scrolled} menuOpen={menuOpen} setMenuOpen={setMenuOpen} scrollTo={scrollTo} goLogin={goLogin} goSignup={goSignup} />
      <Hero goSignup={goSignup} scrollTo={scrollTo} />
      <StatsBar />
      <FeaturesSection />
      <HowItWorks />
      <Testimonials />
      <Pricing goSignup={goSignup} />
      <FinalCTA goSignup={goSignup} />
      <Footer scrollTo={scrollTo} goLogin={goLogin} goSignup={goSignup} />
    </div>
  )
}

/* ============================================================
   NAVBAR
   ============================================================ */
function Navbar({ scrolled, menuOpen, setMenuOpen, scrollTo, goLogin, goSignup }) {
  const [logoFailed, setLogoFailed] = useState(false)
  return (
    <nav
      style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 50,
        height: 64,
        background: scrolled ? 'rgba(14,14,18,0.9)' : 'rgba(14,14,18,0.5)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        borderBottom: scrolled ? '1px solid var(--border)' : '1px solid transparent',
        transition: 'background 0.25s, border-color 0.25s',
      }}
    >
      <div
        style={{
          maxWidth: 1200, margin: '0 auto',
          height: '100%',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '0 20px',
        }}
      >
        <button
          onClick={() => scrollTo('hero')}
          style={{ display: 'flex', alignItems: 'center', gap: 10, background: 'transparent', border: 'none', cursor: 'pointer' }}
        >
          {!logoFailed ? (
            <img
              src="/assets/logo.png" alt=""
              style={{ width: 28, height: 28, objectFit: 'contain' }}
              onError={(e) => { e.currentTarget.style.display = 'none'; setLogoFailed(true) }}
            />
          ) : (
            <Shield size={28} style={{ color: 'var(--red)' }} strokeWidth={2.5} />
          )}
          <span style={{ fontFamily: 'Oxanium, sans-serif', fontWeight: 700, fontSize: 16, color: 'var(--red)', letterSpacing: '0.04em' }}>
            Esports Elite
          </span>
        </button>

        <div style={{ display: 'none', gap: 28, alignItems: 'center' }} className="lg-flex">
          {NAV_ITEMS.map(item => (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              style={{
                background: 'transparent', border: 'none', cursor: 'pointer',
                color: 'var(--text-muted)', fontSize: 13, fontWeight: 500,
              }}
              onMouseEnter={e => e.currentTarget.style.color = 'var(--text-primary)'}
              onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div style={{ display: 'none', gap: 10, alignItems: 'center' }} className="lg-flex">
          <button onClick={goLogin} className="btn btn-secondary btn-sm">Login</button>
          <button onClick={goSignup} className="btn btn-primary btn-sm">Start Free</button>
        </div>

        <button
          onClick={() => setMenuOpen(v => !v)}
          className="mobile-menu-btn"
          style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-primary)', padding: 8 }}
          aria-label="Toggle menu"
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {menuOpen && (
        <div
          style={{
            background: 'var(--bg-surface)',
            borderBottom: '1px solid var(--border)',
            padding: 14,
            display: 'flex',
            flexDirection: 'column',
            gap: 6,
          }}
          className="mobile-menu"
        >
          {NAV_ITEMS.map(item => (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              style={{
                background: 'transparent', border: 'none', cursor: 'pointer',
                color: 'var(--text-muted)', textAlign: 'left',
                padding: '10px 12px', borderRadius: 8, fontSize: 14,
              }}
            >
              {item.label}
            </button>
          ))}
          <button onClick={goLogin} className="btn btn-secondary" style={{ marginTop: 6 }}>Login</button>
          <button onClick={goSignup} className="btn btn-primary">Start Free</button>
        </div>
      )}

      <style>{`
        @media (min-width: 768px) {
          .lg-flex { display: flex !important; }
          .mobile-menu-btn { display: none; }
          .mobile-menu { display: none; }
        }
      `}</style>
    </nav>
  )
}

/* ============================================================
   HERO
   ============================================================ */
function Hero({ goSignup, scrollTo }) {
  return (
    <section
      id="hero"
      style={{
        position: 'relative',
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
        paddingTop: 80,
        paddingBottom: 60,
      }}
    >
      {/* Subtle radial tint — NOT a glow */}
      <div
        style={{
          position: 'absolute', inset: 0, zIndex: 0, pointerEvents: 'none',
          background: 'radial-gradient(circle at 50% 30%, rgba(232,0,28,0.06), transparent 60%)',
        }}
      />

      <div style={{ position: 'relative', zIndex: 1, maxWidth: 1080, margin: '0 auto', padding: '0 20px', textAlign: 'center' }}>
        <span
          className="badge badge-muted"
          style={{ display: 'inline-flex', alignItems: 'center', gap: 6, marginBottom: 22 }}
        >
          <Swords size={12} /> INDIA'S BGMI TRAINING PLATFORM
        </span>

        <h1
          style={{
            fontFamily: 'Oxanium, sans-serif',
            fontWeight: 800,
            fontSize: 'clamp(36px, 6vw, 64px)',
            lineHeight: 1.05,
            letterSpacing: '0.01em',
            color: 'var(--text-primary)',
            margin: 0,
          }}
        >
          Where Grind <span style={{ color: 'var(--red)' }}>Becomes</span> Greatness
        </h1>

        <p
          style={{
            color: 'var(--text-muted)',
            fontSize: 17,
            lineHeight: 1.6,
            maxWidth: 580,
            margin: '20px auto 0',
          }}
        >
          Stop grinding blind. Train with purpose. Track every drill, analyse every match, and improve like a professional BGMI team.
        </p>

        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', marginTop: 28, flexWrap: 'wrap' }}>
          <button onClick={goSignup} className="btn btn-primary btn-lg">
            Start Free — 90 days <ArrowRight size={14} />
          </button>
          <button onClick={() => scrollTo('how-it-works')} className="btn btn-secondary btn-lg">
            See how it works
          </button>
        </div>

        <div
          style={{
            display: 'flex', gap: 18, justifyContent: 'center',
            marginTop: 22, fontSize: 12,
            color: 'var(--text-subtle)', flexWrap: 'wrap',
          }}
        >
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <Check size={12} style={{ color: 'var(--green)' }} /> No credit card
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <Check size={12} style={{ color: 'var(--green)' }} /> Free for 90 days
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <Check size={12} style={{ color: 'var(--green)' }} /> Cancel anytime
          </span>
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   STATS BAR
   ============================================================ */
const FALLBACK_STATS = { players: 500, drills: 10000, matches: 5000 }

function StatsBar() {
  const [ref, inView] = useInView(0.3)
  const [counts, setCounts] = useState(null)

  useEffect(() => {
    let cancelled = false
    async function fetchCounts() {
      try {
        const [usersSnap, sessionsSnap, matchesSnap] = await Promise.all([
          getCountFromServer(collection(db, 'users')),
          getCountFromServer(collectionGroup(db, 'sessions')),
          getCountFromServer(collectionGroup(db, 'matches')),
        ])
        if (cancelled) return
        setCounts({
          players: usersSnap.data().count,
          drills: sessionsSnap.data().count,
          matches: matchesSnap.data().count,
        })
      } catch {
        if (!cancelled) setCounts(FALLBACK_STATS)
      }
    }
    fetchCounts()
    return () => { cancelled = true }
  }, [])

  const ready = counts !== null
  const cells = [
    { value: counts?.drills ?? 0,    label: 'Sessions tracked' },
    { value: counts?.players ?? 0,   label: 'Players' },
    { value: 90,                     label: 'Trial days',  force: '90' },
    { value: 7,                      label: 'Levels',      force: '7'  },
  ]

  return (
    <section
      ref={ref}
      style={{
        background: 'var(--bg-surface)',
        borderTop: '1px solid var(--border)',
        borderBottom: '1px solid var(--border)',
        padding: '36px 20px',
      }}
    >
      <div
        style={{
          maxWidth: 1080, margin: '0 auto',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
          gap: 24,
        }}
      >
        {cells.map(s => (
          <StatCell key={s.label} value={s.value} label={s.label} force={s.force} ready={ready} animate={inView && ready} />
        ))}
      </div>
    </section>
  )
}

function StatCell({ value, label, force, ready, animate }) {
  const animated = useCountUp(value, animate)
  const display = force ? force : ready ? formatNum(animate ? animated : value) : null
  return (
    <div style={{ textAlign: 'center' }}>
      {ready ? (
        <span style={{ fontFamily: 'Oxanium, sans-serif', fontWeight: 800, fontSize: 28, color: 'var(--text-primary)' }}>
          {display}
        </span>
      ) : (
        <span className="skeleton" style={{ width: 80, height: 28, display: 'inline-block' }} />
      )}
      <div className="stat-label" style={{ fontSize: 12 }}>{label}</div>
    </div>
  )
}

/* ============================================================
   FEATURES
   ============================================================ */
function FeaturesSection() {
  return (
    <section id="features" style={{ padding: '80px 20px' }}>
      <div style={{ maxWidth: 1080, margin: '0 auto' }}>
        <h2
          style={{
            fontFamily: 'Oxanium, sans-serif',
            fontWeight: 700,
            fontSize: 'clamp(28px, 4vw, 36px)',
            textAlign: 'center',
            marginBottom: 8,
          }}
        >
          Everything you need to train like a pro
        </h2>
        <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 14, marginBottom: 40 }}>
          Six tools, one workflow, built for BGMI players.
        </p>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
            gap: 16,
          }}
        >
          {FEATURES.map(f => {
            const Icon = f.icon
            return (
              <FeatureCard key={f.title} f={f} Icon={Icon} />
            )
          })}
        </div>
      </div>
    </section>
  )
}

function FeatureCard({ f, Icon }) {
  const ref = useRef(null)
  return (
    <article
      ref={ref}
      className="card"
      onMouseEnter={(e) => e.currentTarget.style.borderColor = 'var(--text-subtle)'}
      onMouseLeave={(e) => e.currentTarget.style.borderColor = 'var(--border)'}
      style={{ transition: 'border-color 0.15s ease' }}
    >
      <div
        style={{
          width: 40, height: 40,
          background: 'var(--bg-elevated)',
          border: '1px solid var(--border)',
          borderRadius: 8,
          color: f.accent,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          marginBottom: 14,
        }}
      >
        <Icon size={18} />
      </div>
      <h3 style={{ fontFamily: 'Oxanium, sans-serif', fontWeight: 700, fontSize: 15, marginBottom: 4 }}>{f.title}</h3>
      <p style={{ color: 'var(--text-muted)', fontSize: 13, lineHeight: 1.5 }}>{f.desc}</p>
    </article>
  )
}

/* ============================================================
   HOW IT WORKS
   ============================================================ */
function HowItWorks() {
  return (
    <section
      id="how-it-works"
      style={{
        background: 'var(--bg-surface)',
        borderTop: '1px solid var(--border)',
        borderBottom: '1px solid var(--border)',
        padding: '80px 20px',
      }}
    >
      <div style={{ maxWidth: 980, margin: '0 auto' }}>
        <h2
          style={{
            fontFamily: 'Oxanium, sans-serif', fontWeight: 700,
            fontSize: 'clamp(26px, 3.5vw, 32px)',
            textAlign: 'center', marginBottom: 6,
          }}
        >
          How it works
        </h2>
        <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 14, marginBottom: 48 }}>
          Three steps. Then you're training like a pro.
        </p>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
            gap: 18,
          }}
        >
          {STEPS.map(step => {
            const Icon = step.icon
            return (
              <div key={step.num} className="card" style={{ textAlign: 'left' }}>
                <div
                  style={{
                    fontFamily: 'Oxanium, sans-serif',
                    fontWeight: 800,
                    fontSize: 32,
                    color: 'var(--border)',
                    marginBottom: 10,
                  }}
                >
                  {step.num}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                  <Icon size={16} style={{ color: 'var(--text-muted)' }} />
                  <h3 style={{ fontFamily: 'Oxanium, sans-serif', fontWeight: 700, fontSize: 16 }}>{step.title}</h3>
                </div>
                <p style={{ color: 'var(--text-muted)', fontSize: 14, lineHeight: 1.5 }}>{step.desc}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   TESTIMONIALS
   ============================================================ */
function Testimonials() {
  return (
    <section style={{ padding: '80px 20px' }}>
      <div style={{ maxWidth: 1080, margin: '0 auto' }}>
        <h2
          style={{
            fontFamily: 'Oxanium, sans-serif', fontWeight: 700,
            fontSize: 'clamp(26px, 3.5vw, 32px)',
            textAlign: 'center', marginBottom: 6,
          }}
        >
          What players are saying
        </h2>
        <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 14, marginBottom: 40 }}>
          Real results, from real BGMI grinders.
        </p>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
            gap: 16,
          }}
        >
          {TESTIMONIALS.map(t => (
            <div key={t.name} className="card">
              <div style={{ display: 'flex', gap: 2, color: 'var(--gold)', marginBottom: 12 }}>
                {[1,2,3,4,5].map(n => <Star key={n} size={14} fill="var(--gold)" />)}
              </div>
              <p style={{ color: 'var(--text-muted)', fontSize: 14, lineHeight: 1.55, marginBottom: 14 }}>
                "{t.quote}"
              </p>
              <div style={{ fontFamily: 'Oxanium, sans-serif', fontWeight: 700, fontSize: 13, color: 'var(--text-primary)' }}>
                {t.name}
              </div>
              <div style={{ fontSize: 12, color: 'var(--text-subtle)' }}>{t.tier}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   PRICING + WAITLIST
   ============================================================ */
function Pricing({ goSignup }) {
  const [email, setEmail] = useState('')
  const [status, setStatus] = useState(null)
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

  async function notifyMe() {
    const clean = email.trim().toLowerCase()
    if (!EMAIL_RE.test(clean)) { setStatus('error'); return }
    setStatus('loading')
    try {
      const existing = await getDocs(query(collection(db, 'waitlist'), where('email', '==', clean)))
      if (!existing.empty) { setStatus('dup'); return }
      await addDoc(collection(db, 'waitlist'), { email: clean, timestamp: serverTimestamp() })
      setStatus('success')
      setEmail('')
    } catch { setStatus('error') }
  }

  return (
    <section
      id="pricing"
      style={{
        background: 'var(--bg-surface)',
        borderTop: '1px solid var(--border)',
        borderBottom: '1px solid var(--border)',
        padding: '80px 20px',
      }}
    >
      <div style={{ maxWidth: 880, margin: '0 auto' }}>
        <h2
          style={{
            fontFamily: 'Oxanium, sans-serif', fontWeight: 700,
            fontSize: 'clamp(26px, 3.5vw, 32px)',
            textAlign: 'center', marginBottom: 6,
          }}
        >
          Pricing
        </h2>
        <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 14, marginBottom: 40 }}>
          Simple. Start free today.
        </p>

        <div
          style={{
            maxWidth: 400,
            margin: '0 auto',
            background: 'var(--bg-base)',
            border: '1px solid var(--border)',
            borderTop: '2px solid var(--red)',
            borderRadius: 'var(--radius-lg)',
            padding: 28,
          }}
        >
          <div
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              fontFamily: 'Inter, sans-serif', fontWeight: 600, fontSize: 11,
              color: 'var(--red)', textTransform: 'uppercase', letterSpacing: '0.08em',
            }}
          >
            <Gift size={14} /> Free trial
          </div>
          <div
            style={{
              fontFamily: 'Oxanium, sans-serif', fontWeight: 800,
              fontSize: 40, marginTop: 12, color: 'var(--text-primary)',
            }}
          >
            ₹0
          </div>
          <div style={{ color: 'var(--text-muted)', fontSize: 13, marginTop: 2 }}>
            90 days. No credit card. Cancel anytime.
          </div>

          <ul style={{ listStyle: 'none', padding: 0, margin: '20px 0', display: 'flex', flexDirection: 'column', gap: 8 }}>
            {PRICING_PERKS.map(p => (
              <li key={p} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--text-primary)' }}>
                <Check size={14} style={{ color: 'var(--green)' }} /> {p}
              </li>
            ))}
          </ul>

          <button onClick={goSignup} className="btn btn-primary btn-lg" style={{ width: '100%' }}>
            Start Free
          </button>
          <div style={{ textAlign: 'center', fontSize: 12, color: 'var(--text-subtle)', marginTop: 10 }}>
            ₹99/mo premium plan coming soon
          </div>
        </div>

        {/* Waitlist */}
        <div style={{ maxWidth: 480, margin: '40px auto 0', textAlign: 'center' }}>
          <div style={{ fontSize: 14, color: 'var(--text-primary)', fontWeight: 600 }}>
            Premium plans coming soon
          </div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 4, marginBottom: 14 }}>
            Be the first to know.
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <input
              type="email"
              value={email}
              onChange={(e) => { setEmail(e.target.value); if (status) setStatus(null) }}
              placeholder="your@email.com"
              className="input"
              style={{ flex: 1, minWidth: 200 }}
            />
            <button onClick={notifyMe} disabled={status === 'loading'} className="btn btn-primary">
              {status === 'loading' ? 'Adding…' : 'Join'}
            </button>
          </div>
          {status === 'success' && (
            <div style={{ marginTop: 12, display: 'flex', justifyContent: 'center' }}>
              <span className="badge badge-green">You're on the list ✓</span>
            </div>
          )}
          {status === 'dup' && (
            <div style={{ marginTop: 12, display: 'flex', justifyContent: 'center' }}>
              <span className="badge badge-amber">Already on the list</span>
            </div>
          )}
          {status === 'error' && (
            <div style={{ marginTop: 12, fontSize: 12, color: 'var(--red)' }}>
              Couldn't save your email. Try again.
            </div>
          )}
        </div>
      </div>
    </section>
  )
}

/* ============================================================
   FINAL CTA
   ============================================================ */
function FinalCTA({ goSignup }) {
  return (
    <section style={{ padding: '80px 20px', textAlign: 'center' }}>
      <h2
        style={{
          fontFamily: 'Oxanium, sans-serif', fontWeight: 700,
          fontSize: 'clamp(26px, 3.5vw, 32px)', marginBottom: 12,
        }}
      >
        Ready to train like a pro?
      </h2>
      <p style={{ color: 'var(--text-muted)', fontSize: 14, marginBottom: 24 }}>
        Free for 90 days. No credit card.
      </p>
      <button onClick={goSignup} className="btn btn-primary btn-lg">
        Start free — 90 days <ArrowRight size={14} />
      </button>
    </section>
  )
}

/* ============================================================
   FOOTER
   ============================================================ */
function Footer({ scrollTo, goLogin, goSignup }) {
  const [logoFailed, setLogoFailed] = useState(false)
  return (
    <footer
      style={{
        background: 'var(--bg-surface)',
        borderTop: '1px solid var(--border)',
        padding: '40px 20px 24px',
      }}
    >
      <div
        style={{
          maxWidth: 1080, margin: '0 auto',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
          gap: 32,
        }}
      >
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            {!logoFailed ? (
              <img
                src="/assets/logo.png" alt=""
                style={{ width: 20, height: 20, objectFit: 'contain' }}
                onError={(e) => { e.currentTarget.style.display = 'none'; setLogoFailed(true) }}
              />
            ) : (
              <Shield size={20} style={{ color: 'var(--red)' }} strokeWidth={2.5} />
            )}
            <span style={{ fontFamily: 'Oxanium, sans-serif', fontWeight: 700, fontSize: 14, color: 'var(--red)', letterSpacing: '0.04em' }}>
              Esports Elite
            </span>
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: 12, marginTop: 12, maxWidth: 240, lineHeight: 1.5 }}>
            Pro training platform for BGMI players. Train smart. Climb ranks.
          </p>
        </div>

        <FooterCol title="Product">
          <FooterBtn onClick={() => scrollTo('features')}>Features</FooterBtn>
          <FooterBtn onClick={() => scrollTo('how-it-works')}>How it works</FooterBtn>
          <FooterBtn onClick={() => scrollTo('pricing')}>Pricing</FooterBtn>
          <FooterBtn onClick={goLogin}>Login</FooterBtn>
          <FooterBtn onClick={goSignup}>Sign up</FooterBtn>
        </FooterCol>

        <FooterCol title="Support">
          <FooterLink href="#">Help center</FooterLink>
          <FooterLink href="#">Terms</FooterLink>
          <FooterLink href="#">Privacy</FooterLink>
        </FooterCol>

        <FooterCol title="Connect">
          <FooterLink href="https://instagram.com/esportselite" external><Instagram size={12} /> Instagram</FooterLink>
          <FooterLink href="https://discord.com" external><MessageCircle size={12} /> Discord</FooterLink>
          <FooterLink href="https://youtube.com/@esportselite" external><Youtube size={12} /> YouTube</FooterLink>
          <FooterLink href="https://twitter.com/esportselite" external><Twitter size={12} /> Twitter</FooterLink>
        </FooterCol>
      </div>

      <div
        style={{
          maxWidth: 1080, margin: '32px auto 0',
          paddingTop: 18,
          borderTop: '1px solid var(--border)',
          textAlign: 'center',
          color: 'var(--text-subtle)',
          fontSize: 12,
        }}
      >
        © 2025 Esports Elite. All rights reserved.
      </div>
    </footer>
  )
}

function FooterCol({ title, children }) {
  return (
    <div>
      <div className="label" style={{ marginBottom: 12 }}>{title}</div>
      <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {children}
      </ul>
    </div>
  )
}

function FooterBtn({ onClick, children }) {
  return (
    <li>
      <button
        onClick={onClick}
        style={{
          background: 'transparent', border: 'none', cursor: 'pointer',
          color: 'var(--text-muted)', fontSize: 13, padding: 0,
        }}
        onMouseEnter={e => e.currentTarget.style.color = 'var(--text-primary)'}
        onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}
      >
        {children}
      </button>
    </li>
  )
}

function FooterLink({ href, external, children }) {
  return (
    <li>
      <a
        href={href}
        target={external ? '_blank' : undefined}
        rel={external ? 'noopener noreferrer' : undefined}
        style={{
          color: 'var(--text-muted)', fontSize: 13,
          display: 'inline-flex', alignItems: 'center', gap: 6,
        }}
        onMouseEnter={e => e.currentTarget.style.color = 'var(--text-primary)'}
        onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}
      >
        {children}
      </a>
    </li>
  )
}
