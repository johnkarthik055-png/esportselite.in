import { useState, useEffect } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { doc, onSnapshot } from 'firebase/firestore'
import { Wrench, Shield } from 'lucide-react'
import { db } from './utils/firebase.js'

import Landing from './pages/Landing.jsx'
import Login from './pages/Login.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Training from './pages/Training.jsx'
import TrainingPlan from './pages/TrainingPlan.jsx'
import Profile from './pages/Profile.jsx'
import Weapons from './pages/Weapons.jsx'
import Analytics from './pages/Analytics.jsx'
import Progress from './pages/Progress.jsx'
import MaintenancePage from './pages/MaintenancePage.jsx'
import Layout from './components/Layout.jsx'
import AuthGuard from './components/AuthGuard.jsx'
import { useAuth } from './context/AuthContext.jsx'

/* ============================================================
   SPLASH — soft pulse logo + thin red loading bar
   ============================================================ */
function Splash() {
  const [logoFailed, setLogoFailed] = useState(false)
  return (
    <div className="splash">
      {!logoFailed ? (
        <img
          src="/assets/logo.png"
          alt="Esports Elite"
          className="splash-logo"
          onError={(e) => { e.currentTarget.style.display = 'none'; setLogoFailed(true) }}
        />
      ) : (
        <Shield size={64} className="splash-logo" style={{ color: 'var(--red)' }} strokeWidth={2.5} />
      )}
      <div className="splash-bar-track">
        <div className="splash-bar-fill" />
      </div>
      <div className="splash-label">Loading…</div>
    </div>
  )
}

/* ============================================================
   ROUTE GUARDS
   ============================================================ */
function PublicRoute({ children }) {
  const { user, loading } = useAuth()
  if (loading) return <Splash />
  if (user) return <Navigate to="/dashboard" replace />
  return children
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<PublicRoute><Landing /></PublicRoute>} />
      <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />

      <Route
        element={
          <AuthGuard>
            <Layout />
          </AuthGuard>
        }
      >
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/training" element={<Training />} />
        <Route path="/training-plan" element={<TrainingPlan />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/progress" element={<Progress />} />
        <Route path="/weapons" element={<Weapons />} />
        <Route path="/profile" element={<Profile />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

/* ============================================================
   APP ROOT — Firestore maintenance listener
   ============================================================ */
export default function App() {
  const [maintenance, setMaintenance] = useState(null)
  const [checking, setChecking] = useState(true)

  useEffect(() => {
    const unsub = onSnapshot(
      doc(db, 'app_config', 'maintenance'),
      (snap) => {
        if (snap.exists()) setMaintenance(snap.data())
        else setMaintenance({ isActive: false })
        setChecking(false)
      },
      (error) => {
        console.error('Maintenance check:', error)
        setMaintenance({ isActive: false })
        setChecking(false)
      }
    )
    return () => unsub()
  }, [])

  if (checking) return <Splash />

  if (maintenance?.isActive) {
    return <MaintenancePage message={maintenance.message || ''} />
  }

  return <AppRoutes />
}

/* ============================================================
   FALLBACK COMING-SOON PAGE
   Exported here so any route stub can use it.
   ============================================================ */
export function ComingSoon({ title = 'Coming Soon', description = 'This feature is on the roadmap. Check back shortly.' }) {
  return (
    <div className="coming-soon-page">
      <div
        style={{
          width: 56,
          height: 56,
          borderRadius: 12,
          background: 'var(--bg-elevated)',
          border: '1px solid var(--border)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Wrench size={26} style={{ color: 'var(--text-muted)' }} />
      </div>
      <h2 className="heading" style={{ fontSize: 22 }}>{title}</h2>
      <p style={{ color: 'var(--text-muted)', fontSize: 14, maxWidth: 400 }}>
        {description}
      </p>
      <span className="badge badge-amber">Back soon</span>
    </div>
  )
}
